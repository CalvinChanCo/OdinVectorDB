#include <chrono>

namespace pipeann {
  class Timer {
    typedef std::chrono::high_resolution_clock _clock;
    std::chrono::time_point<_clock> check_point;

   public:
    Timer() : check_point(_clock::now()) {
    }

    void reset() {
      check_point = _clock::now();
    }

    long long elapsed() const {
      return std::chrono::duration_cast<std::chrono::microseconds>(_clock::now() - check_point).count();
    }
  };
}  // namespace pipeann
